package com.studyflow

import com.studyflow.ai.AssistantController
import com.studyflow.data.SettingsStore
import com.studyflow.data.StudyRepository
import com.studyflow.focus.FocusTimer
import com.studyflow.focus.Phase
import com.studyflow.logic.plannedReminders
import com.studyflow.notify.NoNotifier
import com.studyflow.notify.Notifier
import com.studyflow.sync.SyncController
import com.studyflow.sync.SyncHost
import kotlinx.coroutines.CoroutineScope
import com.studyflow.util.nowMillis
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Everything the UI needs, created once per process by each platform's entry point
 * (so a running focus timer survives screen rotation and navigation).
 */
class AppContainer(
    val repository: StudyRepository,
    val settings: SettingsStore,
    scope: CoroutineScope,
    /** Only the desktop app provides a hub. */
    val syncHost: SyncHost? = null,
    /** Called when a focus or break phase ends (beep / ringtone). */
    val alert: () -> Unit = {},
    /** Shows deadline reminders as system notifications. */
    val notifier: Notifier = NoNotifier,
) {
    val sync = SyncController(repository, settings)
    val assistant = AssistantController(settings, scope)

    val timer = FocusTimer(scope) { done ->
        if (done.phase == Phase.FOCUS) {
            repository.addSession(done.label, done.startedAt, done.durationSec)
        }
        alert()
    }

    init {
        scope.launch {
            settings.loaded.first { it }
            val s = settings.state.value
            timer.setDurations(s.focusMinutes, s.breakMinutes)
        }

        // keep the scheduled reminders in step with the deadlines and the reminder settings
        scope.launch {
            settings.loaded.first { it }
            repository.loaded.first { it }
            combine(repository.data, settings.state) { data, s ->
                plannedReminders(data.tasks, s.notificationsOn, s.defaultRemindMinutes, nowMillis())
            }.distinctUntilChanged().collect { notifier.sync(it) }
        }
    }
}
