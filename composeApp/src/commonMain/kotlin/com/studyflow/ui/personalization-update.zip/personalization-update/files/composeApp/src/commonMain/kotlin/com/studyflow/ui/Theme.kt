package com.studyflow.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.studyflow.logic.AccentRgb
import com.studyflow.logic.accentFromSeed

/** Theme modes stored in settings. */
const val THEME_SYSTEM = 0
const val THEME_LIGHT = 1
const val THEME_DARK = 2
const val THEME_AMOLED = 3

/** Indigo, the colour the app starts with (as an ARGB number). */
val DefaultAccent: Int = 0xFF4F46E5.toInt()

private fun rgbColor(rgb: Int): Color = Color(0xFF000000.toInt() or (rgb and 0xFFFFFF))

private fun buildScheme(a: AccentRgb, dark: Boolean, amoled: Boolean): ColorScheme {
    val primary = rgbColor(a.primary)
    val onPrimary = rgbColor(a.onPrimary)
    val container = rgbColor(a.container)
    val onContainer = rgbColor(a.onContainer)
    val secondary = rgbColor(a.secondary)

    return if (!dark) {
        lightColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = container,
            onPrimaryContainer = onContainer,
            secondary = secondary,
            onSecondary = Color.White,
            // chips and the selected navigation item follow the accent as well
            secondaryContainer = container,
            onSecondaryContainer = onContainer,
            background = Color(0xFFF4F6FB),
            onBackground = Color(0xFF0F172A),
            surface = Color(0xFFF4F6FB),
            onSurface = Color(0xFF0F172A),
            surfaceVariant = Color(0xFFE6EAF2),
            onSurfaceVariant = Color(0xFF55627A),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = Color(0xFFF8FAFC),
            surfaceContainer = Color.White,
            surfaceContainerHigh = Color.White,
            surfaceContainerHighest = Color(0xFFEEF1F7),
            outline = Color(0xFF8A94A8),
            outlineVariant = Color(0xFFD5DAE5),
            error = Color(0xFFDC2626),
        )
    } else if (amoled) {
        // pure black saves battery on OLED screens; cards are only just lighter so they stay visible
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = container,
            onPrimaryContainer = onContainer,
            secondary = secondary,
            onSecondary = Color.Black,
            secondaryContainer = container,
            onSecondaryContainer = onContainer,
            background = Color.Black,
            onBackground = Color(0xFFE6E6E6),
            surface = Color.Black,
            onSurface = Color(0xFFE6E6E6),
            surfaceVariant = Color(0xFF1C1C1E),
            onSurfaceVariant = Color(0xFFA1A1AA),
            surfaceContainerLowest = Color.Black,
            surfaceContainerLow = Color(0xFF080808),
            surfaceContainer = Color(0xFF0E0E0E),
            surfaceContainerHigh = Color(0xFF151515),
            surfaceContainerHighest = Color(0xFF1E1E1E),
            outline = Color(0xFF5B5B63),
            outlineVariant = Color(0xFF26262B),
            error = Color(0xFFF87171),
        )
    } else {
        darkColorScheme(
            primary = primary,
            onPrimary = onPrimary,
            primaryContainer = container,
            onPrimaryContainer = onContainer,
            secondary = secondary,
            onSecondary = Color(0xFF0B1020),
            secondaryContainer = container,
            onSecondaryContainer = onContainer,
            background = Color(0xFF0B1020),
            onBackground = Color(0xFFE2E8F0),
            surface = Color(0xFF0B1020),
            onSurface = Color(0xFFE2E8F0),
            surfaceVariant = Color(0xFF1E293B),
            onSurfaceVariant = Color(0xFF9AA7BD),
            surfaceContainerLowest = Color(0xFF080C18),
            surfaceContainerLow = Color(0xFF0F1526),
            surfaceContainer = Color(0xFF121A2E),
            surfaceContainerHigh = Color(0xFF172038),
            surfaceContainerHighest = Color(0xFF1E2842),
            outline = Color(0xFF64748B),
            outlineVariant = Color(0xFF2A3550),
            error = Color(0xFFF87171),
        )
    }
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

private fun appTypography(font: FontFamily?): Typography {
    val base = Typography()
    if (font == null) return base
    return base.copy(
        displayLarge = base.displayLarge.copy(fontFamily = font, letterSpacing = (-0.5).sp),
        displayMedium = base.displayMedium.copy(fontFamily = font, letterSpacing = (-0.5).sp),
        displaySmall = base.displaySmall.copy(fontFamily = font),
        headlineLarge = base.headlineLarge.copy(fontFamily = font, letterSpacing = (-0.3).sp),
        headlineMedium = base.headlineMedium.copy(fontFamily = font, letterSpacing = (-0.3).sp),
        headlineSmall = base.headlineSmall.copy(fontFamily = font),
        titleLarge = base.titleLarge.copy(fontFamily = font),
        titleMedium = base.titleMedium.copy(fontFamily = font),
        titleSmall = base.titleSmall.copy(fontFamily = font),
        bodyLarge = base.bodyLarge.copy(fontFamily = font),
        bodyMedium = base.bodyMedium.copy(fontFamily = font),
        bodySmall = base.bodySmall.copy(fontFamily = font),
        labelLarge = base.labelLarge.copy(fontFamily = font),
        labelMedium = base.labelMedium.copy(fontFamily = font),
        labelSmall = base.labelSmall.copy(fontFamily = font),
    )
}

/** Colours a class can be tagged with in the timetable. */
val ClassPalette = listOf(
    Color(0xFF6366F1),
    Color(0xFF14B8A6),
    Color(0xFFF59E0B),
    Color(0xFFEC4899),
    Color(0xFF3B82F6),
    Color(0xFF84CC16),
)

/**
 * @param themeMode [THEME_SYSTEM], [THEME_LIGHT], [THEME_DARK] or [THEME_AMOLED]
 * @param accentSeed any colour (ARGB number); the rest of the palette is derived from it
 */
@Composable
fun StudyFlowTheme(
    themeMode: Int = THEME_SYSTEM,
    accentSeed: Int = DefaultAccent,
    fontFamily: FontFamily? = null,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val amoled = themeMode == THEME_AMOLED
    val dark = when (themeMode) {
        THEME_LIGHT -> false
        THEME_DARK, THEME_AMOLED -> true
        else -> systemDark
    }
    val scheme = remember(accentSeed, dark, amoled) { buildScheme(accentFromSeed(accentSeed, dark), dark, amoled) }
    val typography = remember(fontFamily) { appTypography(fontFamily) }

    // keeps the status bar icons readable when the in-app theme differs from the phone's
    SystemBarsEffect(darkTheme = dark)

    MaterialTheme(
        colorScheme = scheme,
        typography = typography,
        shapes = AppShapes,
        content = content,
    )
}
