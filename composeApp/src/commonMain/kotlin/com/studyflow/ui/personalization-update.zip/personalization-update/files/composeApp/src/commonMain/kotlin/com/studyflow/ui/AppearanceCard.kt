package com.studyflow.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studyflow.logic.AccentSwatches

private val ThemeModes = listOf("System", "Light", "Dark", "AMOLED")

private fun swatchColor(rgb: Int) = Color(0xFF000000.toInt() or rgb)

/** Theme mode chips, a grid of accent colours and a box for any colour you like (hex). */
@Composable
fun AppearanceCard(
    themeMode: Int,
    accentSeed: Int,
    onThemeMode: (Int) -> Unit,
    onAccent: (Int) -> Unit,
) {
    val currentRgb = accentSeed and 0xFFFFFF
    val currentHex = currentRgb.toString(16).padStart(6, '0').uppercase()
    var hexText by remember(currentRgb) { mutableStateOf(currentHex) }

    SoftCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Appearance", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

            Text("Theme", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ThemeModes.forEachIndexed { index, label ->
                    FilterChip(selected = themeMode == index, onClick = { onThemeMode(index) }, label = { Text(label) })
                }
            }
            if (themeMode == THEME_AMOLED) {
                Text(
                    "Pure black background: saves battery on OLED and AMOLED screens.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Text(
                "Accent colour",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AccentSwatches.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { rgb ->
                        val selected = rgb == currentRgb
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(swatchColor(rgb))
                                .then(
                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                    else Modifier,
                                )
                                .clickable { onAccent(0xFF000000.toInt() or rgb) },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Color.White))
                        }
                    }
                    repeat(6 - row.size) { Spacer(Modifier.size(40.dp)) }
                }
            }

            OutlinedTextField(
                value = hexText,
                onValueChange = { typed ->
                    val clean = typed.filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }.take(6).uppercase()
                    hexText = clean
                    if (clean.length == 6) onAccent(0xFF000000.toInt() or clean.toInt(16))
                },
                label = { Text("Or type any colour (hex)") },
                prefix = { Text("#") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
