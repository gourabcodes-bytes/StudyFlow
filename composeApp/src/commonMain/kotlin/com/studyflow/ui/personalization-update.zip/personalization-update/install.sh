#!/bin/bash
# Copies the personalization update into your StudyFlow project.
# Usage:  bash install.sh /path/to/StudyFlow
set -e
PROJECT="${1:-$HOME/Downloads/StudyFlow}"
HERE="$(cd "$(dirname "$0")" && pwd)"
if [ ! -f "$PROJECT/settings.gradle.kts" ] || [ ! -d "$PROJECT/composeApp/src" ]; then
  echo "Could not find the StudyFlow project at: $PROJECT"
  echo "Run it like this:  bash install.sh /full/path/to/StudyFlow"
  exit 1
fi
cp -R "$HERE/files/composeApp/." "$PROJECT/composeApp/"
echo "Copied $(find "$HERE/files" -type f | wc -l | tr -d ' ') files into $PROJECT"
STRAY=$(find "$PROJECT/composeApp/src" -name "* (1).*" 2>/dev/null || true)
if [ -n "$STRAY" ]; then
  echo ""
  echo "WARNING: duplicate files with '(1)' in the name exist and may cause errors:"
  echo "$STRAY"
fi
echo ""
echo "Done. In Android Studio choose File > Sync Project with Gradle Files, then run the app."
