package com.studyflow.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.studyflow.AppContainer
import com.studyflow.ai.AssistMode
import com.studyflow.ai.ChatMessage
import com.studyflow.ai.Role
import com.studyflow.ai.rememberPdfPicker
import com.studyflow.ai.splitAnswers
import com.studyflow.logic.noteTitleFrom

/**
 * The study assistant: ask a question, pick a mode (step by step, notes, examples, practice,
 * quiz) and optionally attach a PDF to learn from your own material.
 */
@Composable
fun AssistantScreen(container: AppContainer, onOpenSettings: () -> Unit) {
    val assistant = container.assistant
    val messages by assistant.messages.collectAsState()
    val busy by assistant.busy.collectAsState()
    val attachment by assistant.attachment.collectAsState()
    val notice by assistant.notice.collectAsState()
    val settings by container.settings.state.collectAsState()
    val data by container.repository.data.collectAsState()
    val noteCount = data.notes.count { !it.deleted }
    var showNotes by rememberSaveable { mutableStateOf(false) }

    var input by rememberSaveable { mutableStateOf("") }
    var mode by remember { mutableStateOf<AssistMode?>(null) }
    val listState = rememberLazyListState()

    val pickPdf = rememberPdfPicker { picked ->
        if (picked != null) assistant.attachPdf(picked.name, picked.bytes)
    }

    // keep the newest message (or the typing dots) in view
    LaunchedEffect(messages.size, busy) {
        val count = messages.size + if (busy) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    val canSend = !busy && (input.isNotBlank() || attachment != null)

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(Modifier.widthIn(max = 860.dp).fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 20.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    ScreenHeader("Study assistant", "Learn step by step, or study from your own PDF")
                }
                TextButton(onClick = { showNotes = !showNotes }) {
                    Text(if (showNotes) "Back to chat" else "Notes ($noteCount)")
                }
                if (!showNotes) {
                    TextButton(
                        onClick = { assistant.newChat() },
                        enabled = messages.isNotEmpty() || attachment != null,
                    ) { Text("New chat") }
                }
            }

            if (showNotes) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    NotesScreen(
                        data = data,
                        onSave = container.repository::saveNote,
                        onDelete = container.repository::deleteNote,
                    )
                }
            } else {

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (messages.isEmpty() && !busy) {
                    WelcomePane(
                        hasKey = settings.apiKey.isNotBlank(),
                        onOpenSettings = onOpenSettings,
                        onSuggestion = { topic, suggestionMode -> assistant.send(topic, suggestionMode) },
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        items(messages, key = { it.id }) { message ->
                            ChatBubble(
                                message,
                                Modifier.animateItem(),
                                onSaveNote = { text -> container.repository.addNote(noteTitleFrom(text), text) },
                            )
                        }
                        if (busy) {
                            item { TypingBubble() }
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth().imePadding().padding(horizontal = 20.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                notice?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                attachment?.let { pdf ->
                    AssistChip(
                        onClick = { assistant.removeAttachment() },
                        label = { Text("PDF: ${pdf.name}  (tap to remove)") },
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistMode.entries.forEach { option ->
                        FilterChip(
                            selected = mode == option,
                            onClick = { mode = if (mode == option) null else option },
                            label = { Text(option.label) },
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedButton(onClick = pickPdf, enabled = !busy) { Text("PDF") }
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = {
                            Text(if (attachment != null) "Ask about your PDF…" else "Ask a question…")
                        },
                        maxLines = 4,
                        modifier = Modifier.weight(1f),
                    )
                    Button(
                        enabled = canSend,
                        onClick = {
                            assistant.send(input, mode)
                            input = ""
                            mode = null
                        },
                    ) { Text("Send") }
                }
            }
            }
        }
    }
}

@Composable
private fun WelcomePane(
    hasKey: Boolean,
    onOpenSettings: () -> Unit,
    onSuggestion: (String, AssistMode) -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().appear(0),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        ) {
            Column(
                modifier = Modifier
                    .background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary)))
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    "Hi, I'm your study assistant",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = scheme.onPrimary,
                )
                Text(
                    "Ask me to explain a topic step by step, write simple notes, show worked examples or test you " +
                        "with practice questions. Attach a PDF and I will teach from your own material.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onPrimary.copy(alpha = 0.92f),
                )
            }
        }

        if (!hasKey) {
            SoftCard(Modifier.appear(1)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("One quick step first", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Add your API key in Settings so the assistant can answer.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Button(onClick = onOpenSettings) { Text("Open Settings") }
                }
            }
        }

        SectionLabel("Try one of these")
        Suggestion("Explain Thevenin's theorem simply", index = 2) { onSuggestion("Thevenin's theorem", AssistMode.EXPLAIN) }
        Suggestion("Make simple notes on Ohm's law", index = 3) { onSuggestion("Ohm's law", AssistMode.NOTES) }
        Suggestion("Give me practice questions on Kirchhoff's laws", index = 4) { onSuggestion("Kirchhoff's laws", AssistMode.PRACTICE) }
        Suggestion("Quiz me on the basics of diodes", index = 5) { onSuggestion("the basics of diodes", AssistMode.QUIZ) }
    }
}

@Composable
private fun Suggestion(label: String, index: Int, onClick: () -> Unit) {
    SoftCard(Modifier.appear(index).clickable(onClick = onClick)) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(16.dp))
    }
}

@Composable
private fun ChatBubble(message: ChatMessage, modifier: Modifier = Modifier, onSaveNote: (String) -> Unit = {}) {
    val scheme = MaterialTheme.colorScheme
    when (message.role) {
        Role.USER -> Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 4.dp, bottomStart = 20.dp))
                    .background(Brush.linearGradient(listOf(scheme.primary, scheme.secondary)))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (message.pdfName != null) {
                    Text(
                        "PDF: ${message.pdfName}",
                        style = MaterialTheme.typography.labelMedium,
                        color = scheme.onPrimary.copy(alpha = 0.85f),
                    )
                }
                Text(message.text, style = MaterialTheme.typography.bodyLarge, color = scheme.onPrimary)
            }
        }

        Role.ASSISTANT -> Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Column(
                modifier = Modifier
                    .widthIn(max = 700.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 4.dp))
                    .background(scheme.surfaceContainerHigh)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                AssistantContent(message.text)
                val clipboard = LocalClipboardManager.current
                Row {
                    TextButton(onClick = { clipboard.setText(AnnotatedString(message.text)) }) { Text("Copy") }
                    var saved by remember { mutableStateOf(false) }
                    TextButton(
                        enabled = !saved,
                        onClick = {
                            onSaveNote(message.text)
                            saved = true
                        },
                    ) { Text(if (saved) "Saved to notes" else "Save as note") }
                }
            }
        }

        Role.ERROR -> Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Column(
                modifier = Modifier
                    .widthIn(max = 700.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(scheme.error.copy(alpha = 0.12f))
                    .padding(14.dp),
            ) {
                Text(message.text, style = MaterialTheme.typography.bodyMedium, color = scheme.error)
            }
        }
    }
}

/** An answer, with practice-question answers hidden behind a button until the student asks. */
@Composable
private fun AssistantContent(text: String) {
    val (main, answers) = remember(text) { splitAnswers(text) }
    var showAnswers by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        MarkdownText(main)
        if (answers != null) {
            OutlinedButton(onClick = { showAnswers = !showAnswers }) {
                Text(if (showAnswers) "Hide answers" else "Show answers")
            }
            AnimatedVisibility(visible = showAnswers) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    HorizontalDivider()
                    MarkdownText(answers)
                }
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    val transition = rememberInfiniteTransition(label = "typing")
    val dotColor = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 4.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(3) { index ->
            val alpha by transition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 600, delayMillis = index * 150),
                    repeatMode = RepeatMode.Reverse,
                ),
                label = "dot$index",
            )
            Box(Modifier.size(8.dp).clip(CircleShape).background(dotColor.copy(alpha = alpha)))
        }
        Text(
            "  Thinking…",
            style = MaterialTheme.typography.bodySmall,
            color = dotColor,
        )
    }
}
